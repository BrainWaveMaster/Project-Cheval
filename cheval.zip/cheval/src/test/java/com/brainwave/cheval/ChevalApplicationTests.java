package com.brainwave.cheval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChevalApplicationTests {

	@Test
	void contextLoads() {
	}

}
